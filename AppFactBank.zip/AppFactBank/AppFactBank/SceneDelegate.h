//
//  SceneDelegate.h
//  AppFactBank
//
//  Created by geralduwu on 2025-03-19.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

