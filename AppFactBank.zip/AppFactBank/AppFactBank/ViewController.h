//
//  ViewController.h
//  AppFactBank
//
//  Created by geralduwu on 2025-03-19.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

