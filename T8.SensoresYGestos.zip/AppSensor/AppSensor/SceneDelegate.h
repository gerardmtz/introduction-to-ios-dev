//
//  SceneDelegate.h
//  AppSensor
//
//  Created by geralduwu on 2025-05-01.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

