//
//  ViewController.h
//  AppSensor
//
//  Created by geralduwu on 2025-05-01.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *statusLabel;

@end

